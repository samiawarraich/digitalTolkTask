package com.example.translation.repository;

import com.example.translation.entity.Translation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.stream.Stream;

public interface TranslationRepository extends JpaRepository<Translation, Long> {
    @Query("SELECT t FROM Translation t")
    Stream<Translation> streamAll();
}
