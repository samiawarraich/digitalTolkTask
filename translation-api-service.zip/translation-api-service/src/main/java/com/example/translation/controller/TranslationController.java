package com.example.translation.controller;

import com.example.translation.dto.TranslationDTO;
import com.example.translation.entity.Translation;
import com.example.translation.service.TranslationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/translations")
public class TranslationController {

    private final TranslationService translationService;

    public TranslationController(TranslationService translationService) {
        this.translationService = translationService;
    }

    @PostMapping
    public ResponseEntity<Translation> create(@RequestBody TranslationDTO dto) {
        return ResponseEntity.ok(translationService.saveTranslation(dto));
    }

    @GetMapping("/export")
    public ResponseEntity<Map<String, Map<String, String>>> export() {
        long start = System.currentTimeMillis();
        Map<String, Map<String, String>> data = translationService.exportTranslations();
        long end = System.currentTimeMillis();
        System.out.println("Export response time: " + (end - start) + "ms");
        return ResponseEntity.ok(data);
    }
}
