package com.example.translation.dto;

import java.util.Set;

public class TranslationDTO {
    public String translationKey;
    public String locale;
    public String content;
    public Set<String> tags;

    public String getTranslationKey() { return translationKey; }
    public void setTranslationKey(String translationKey) { this.translationKey = translationKey; }

    public String getLocale() { return locale; }
    public void setLocale(String locale) { this.locale = locale; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public Set<String> getTags() { return tags; }
    public void setTags(Set<String> tags) { this.tags = tags; }
}
