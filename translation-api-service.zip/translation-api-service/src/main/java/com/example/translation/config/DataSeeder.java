package com.example.translation.config;

import com.example.translation.entity.Tag;
import com.example.translation.entity.Translation;
import com.example.translation.repository.TagRepository;
import com.example.translation.repository.TranslationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.*;

@Service
public class DataSeeder implements CommandLineRunner {

    private final TranslationRepository translationRepository;
    private final TagRepository tagRepository;

    public DataSeeder(TranslationRepository translationRepository, TagRepository tagRepository) {
        this.translationRepository = translationRepository;
        this.tagRepository = tagRepository;
    }

    @Override
    public void run(String... args) {
        List<String> locales = Arrays.asList("en", "fr", "es");
        List<String> tags = Arrays.asList("web", "mobile", "desktop");

        List<Tag> tagEntities = new ArrayList<>();
        for (String t : tags) {
            tagEntities.add(tagRepository.findByName(t).orElseGet(() -> tagRepository.save(new Tag(t))));
        }

        List<Translation> translations = new ArrayList<>();
        for (int i = 0; i < 100000; i++) {
            Translation t = new Translation();
            t.setTranslationKey("key_" + i);
            t.setLocale(locales.get(i % locales.size()));
            t.setContent("Content for key_" + i);
            t.setTags(Set.of(tagEntities.get(i % tagEntities.size())));
            translations.add(t);

            if (i % 1000 == 0) {
                translationRepository.saveAll(translations);
                translations.clear();
            }
        }
        if (!translations.isEmpty()) {
            translationRepository.saveAll(translations);
        }
    }
}
