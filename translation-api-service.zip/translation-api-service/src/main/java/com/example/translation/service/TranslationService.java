package com.example.translation.service;

import com.example.translation.dto.TranslationDTO;
import com.example.translation.entity.Tag;
import com.example.translation.entity.Translation;
import com.example.translation.repository.TagRepository;
import com.example.translation.repository.TranslationRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public interface TranslationService {

    public Translation saveTranslation(TranslationDTO dto);

    public Map<String, Map<String, String>> exportTranslations();

}

