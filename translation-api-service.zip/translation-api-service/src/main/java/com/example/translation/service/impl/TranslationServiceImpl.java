package com.example.translation.service.impl;

import com.example.translation.dto.TranslationDTO;
import com.example.translation.service.TranslationService;
import com.example.translation.entity.Tag;
import com.example.translation.entity.Translation;
import com.example.translation.repository.TagRepository;
import com.example.translation.repository.TranslationRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class TranslationServiceImpl implements TranslationService {

    private final TranslationRepository translationRepository;
    private final TagRepository tagRepository;

    public TranslationService(TranslationRepository translationRepository, TagRepository tagRepository) {
        this.translationRepository = translationRepository;
        this.tagRepository = tagRepository;
    }

    public Translation saveTranslation(TranslationDTO dto) {
        Translation translation = new Translation();
        translation.setTranslationKey(dto.getTranslationKey());
        translation.setLocale(dto.getLocale());
        translation.setContent(dto.getContent());

        Set<Tag> tags = dto.getTags().stream()
                .map(tag -> tagRepository.findByName(tag).orElseGet(() -> tagRepository.save(new Tag(tag))))
                .collect(Collectors.toSet());

        translation.setTags(tags);
        return translationRepository.save(translation);
    }

    public Map<String, Map<String, String>> exportTranslations() {
        Map<String, Map<String, String>> result = new HashMap<>();
        translationRepository.streamAll().forEach(t -> {
            result.computeIfAbsent(t.getLocale(), l -> new HashMap<>())
                    .put(t.getTranslationKey(), t.getContent());
        });
        return result;
    }
}
