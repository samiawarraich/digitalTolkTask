package com.example.translation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TranslationApiServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(TranslationApiServiceApplication.class, args);
    }
}
